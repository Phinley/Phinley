
from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views



urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('heart.urls', namespace='heart')),


    path('password_reset/', auth_views.PasswordResetView.as_view(
        template_name="account/password_reset.html"), name='password_reset'),
    path('password_reset_sent/', auth_views.PasswordResetDoneView.as_view(
        template_name="account/password_reset_sent.html"), name='password_reset_done'),
    path('password_reset_confirm/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(
        template_name="account/password_reset_form.html"), name='password_reset_confirm'),
    path('password_reset_complete/', auth_views.PasswordResetCompleteView.as_view(
        template_name="account/password_reset_complete.html"), name='password_reset_complete'),
]