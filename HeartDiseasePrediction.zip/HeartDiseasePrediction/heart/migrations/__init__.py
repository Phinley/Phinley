
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='PredResults',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('Age', models.FloatField()),
                ('Sex', models.FloatField()),
                ('Chest_pain_type', models.FloatField()),
                ('BP', models.FloatField()),
                ('Cholesterol', models.FloatField()),
                ('FBS_over_120', models.FloatField()),
                ('EKG_results', models.FloatField()),
                ('MAX_HR', models.FloatField()),
                ('Exercise_angina', models.FloatField()),
                ('ST_depression', models.FloatField()),
                ('Slope_of_ST', models.FloatField()),
                ('Number_of_vessels_fluro', models.FloatField()),
                ('Thallium ', models.FloatField()),
                ('Heart_Disease', models.CharField(max_length=30)),
            ],
        ),
    ]