from django.urls import path
from . import views

app_name = "heart"

urlpatterns = [
    path('home/', views.predict, name='prediction_page'),
    path('', views.home, name='home'),
    
    path('h1', views.h1, name='h1'),
    path('h2', views.h2, name='h2'),
    path('predict/', views.predict_chances, name='submit_prediction'),
    path('results/', views.view_results, name='results'),
    path('login/', views.sign_in, name='signin'),
    path('logout/', views.logout, name='logout'),
    path('register/', views.register, name='register'),


]