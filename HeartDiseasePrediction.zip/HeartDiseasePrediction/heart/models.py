from django.db import models


class PredResults(models.Model):

    Age = models.IntegerField()
    Sex = models.IntegerField()
    Chest_pain_type = models.IntegerField()
    BP = models.IntegerField()
    Cholesterol = models.IntegerField()
    FBS_over_120 = models.IntegerField()
    EKG_results = models.IntegerField()
    MAX_HR = models.IntegerField()
    Exercise_angina  = models.IntegerField()
    ST_depression = models.IntegerField()
    Slope_of_ST = models.IntegerField()
    Number_of_vessels_fluro = models.IntegerField()
    Thallium = models.IntegerField()
    Heart_Disease = models.CharField(max_length=30)

    def __str__(self):
        return self.Heart_Disease