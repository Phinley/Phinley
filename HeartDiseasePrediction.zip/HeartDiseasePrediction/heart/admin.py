from django.contrib import admin
from .models import PredResults

class predictionAdmin(admin.ModelAdmin):
    list_display=['id', 'Age','Sex','Chest_pain_type','BP','Cholesterol','FBS_over_120','EKG_results','MAX_HR','Exercise_angina','ST_depression','Slope_of_ST','Number_of_vessels_fluro','Thallium']

admin.site.register(PredResults, predictionAdmin)