import re
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.contrib import auth,messages
import pandas as pd
from .models import PredResults

def home(request):
    template_name='landing/home.html'

    return render(request, template_name)



def h1(request):
    return render(request, 'landing/h1.html')
def h2(request):
    return render(request, 'landing/h2.html')
def register(request):

    if request.method=='POST':
        uname= request.POST['username']
        email=request.POST['email']
        pass1=request.POST['password1']
        pass2=request.POST['password2']

        if pass1 != pass2:

            messages.info(request, 'passwords missmatched . please try again')
            print('password mismatch ')
            return redirect('/register')
        elif len(pass1)<4:
            messages.info(request, 'password should be more than 4 characters!!')
            print('too short ')
            return redirect('/register')

        elif User.objects.filter(username=uname).exists():
            messages.info(request, 'Username exists!!')


            print('username exists ')
            return redirect('/register')

        elif User.objects.filter(email=email).exists():
            messages.info(request, 'Email exists!!!')

            print('email exists ')
            return redirect('/register')
        else:


            user= User.objects.create_user(username=uname, email=email, password=pass2)
            user.save()
            messages.success(request, 'account created successfully!!')

            print('user created ')
            return redirect('/login')

   
    return render(request, 'register.html')


def sign_in(request):
    if request.method=='POST':
        uname= request.POST['username']
        pass1= request.POST['password']

        user= auth.authenticate(username=uname, password=pass1)
        if user is not None:
            auth.login(request,user)
            messages.info(request, 'you are now logged in')

            print('login success')
            return redirect('/home')
        else:
            messages.info(request, 'invalid login details!!')

            print('invalid login')
            return redirect('/login/')


   
    return render(request, 'login.html')


def logout(request):
    auth.logout(request)
    messages.info(request, "you're logged out")

    return redirect('/')
  
def predict(request):
    if not request.user.is_authenticated:
        messages.warning(request, "Sorry, you must be  autheticated!!!")
        return redirect('/')
    else:
        pass
      
    return render(request, 'predict.html')


def predict_chances(request):

    if not request.user.is_authenticated:
        messages.warning(request, "Sorry, you must be  autheticated!!!")
        return redirect('/')
    else:
        pass

    if request.user.is_authenticated:

        if request.POST.get('action') == 'post':

            # Receive data from user
        
            Age = int(request.POST.get('Age'))
            Sex = int(request.POST.get('Sex'))
            Chest_pain_type = int(request.POST.get('Chest_pain_type'))
            BP = int(request.POST.get('BP'))
            Cholesterol = int(request.POST.get('Cholesterol'))
            FBS_over_120 = int(request.POST.get('FBS_over_120'))
            EKG_results = int(request.POST.get('EKG_results'))
            MAX_HR = int(request.POST.get('MAX_HR'))
            Exercise_angina = int(request.POST.get('Exercise_angina'))
            ST_depression = float(request.POST.get('ST_depression'))
            Slope_of_ST = int(request.POST.get('Slope_of_ST'))
            Number_of_vessels_fluro = int(request.POST.get('Number_of_vessels_fluro'))
            Thallium = int(request.POST.get('Thallium'))


     

            

                    # Unpickle model
            model = pd.read_pickle('model.pickle')
            # Make prediction
            
            results = model.predict([[Age,Sex,Chest_pain_type,BP,Cholesterol,FBS_over_120,EKG_results,MAX_HR,Exercise_angina,ST_depression,Slope_of_ST,Number_of_vessels_fluro,Thallium]])

            Heart_Disease = results[0]

            PredResults.objects.create(Age=Age,
                                Sex=Sex, Chest_pain_type=Chest_pain_type, BP=BP, Cholesterol=Cholesterol, FBS_over_120=FBS_over_120, EKG_results=EKG_results, MAX_HR=MAX_HR, Exercise_angina=Exercise_angina, ST_depression=ST_depression, Slope_of_ST=Slope_of_ST, Number_of_vessels_fluro=Number_of_vessels_fluro,Thallium=Thallium, Heart_Disease=Heart_Disease)
            

            return JsonResponse({'results': Heart_Disease,'Age': Age,
                                'Sex': Sex, 'Chest_pain_type': Chest_pain_type, 'BP': BP, 'Cholesterol': Cholesterol, 'FBS_over_120': FBS_over_120, 'EKG_results': EKG_results, 'MAX_HR': MAX_HR, 'Exercise_angina': Exercise_angina, 'ST_depression': ST_depression, 'Slope_of_ST': Slope_of_ST, 'Number_of_vessels_fluro': Number_of_vessels_fluro,'Thallium': Thallium},
                                safe=False)
        







       
        else:
            return redirect('/signin/')


def view_results(request):
    # Submit prediction and show all
    data = {"Heart_Disease_Prediction": PredResults.objects.all()}
    return render(request, "results.html", data)